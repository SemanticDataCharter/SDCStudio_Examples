"""
Django app configuration for vessel_arrival_report.
"""
from django.apps import AppConfig


class Vessel_arrival_reportConfig(AppConfig):
    """App configuration for vessel_arrival_report."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vessel_arrival_report'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import vessel_arrival_report.signals  # noqa: F401
