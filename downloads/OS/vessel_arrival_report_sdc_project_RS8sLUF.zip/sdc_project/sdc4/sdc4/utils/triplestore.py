"""
Triplestore abstraction layer for backend-agnostic RDF operations.

This module provides a factory function that returns the appropriate
triplestore client based on configuration. Currently supports:
- Fuseki (default, Lightweight profile)
- GraphDB (Enterprise profile, future implementation)

Usage:
    from sdc4.utils.triplestore import get_triplestore_client

    client = get_triplestore_client()
    client.upload_graph(rdf_content, graph_uri)
"""
from django.conf import settings
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .fuseki_client import FusekiClient


def get_triplestore_client() -> 'FusekiClient':
    """
    Factory function returning the appropriate triplestore client
    based on TRIPLESTORE_BACKEND setting.

    Currently defaults to Fuseki. GraphDB support will be added in
    the Enterprise profile implementation.

    Returns:
        FusekiClient: Configured triplestore client instance

    Configuration (settings.py):
        TRIPLESTORE_BACKEND: 'fuseki' (default) or 'graphdb'

        For Fuseki:
            FUSEKI_URL: Base URL of Fuseki server
            FUSEKI_DATASET: Dataset name
            FUSEKI_USER: Admin username
            FUSEKI_PASSWORD: Admin password

        For GraphDB (future):
            GRAPHDB_URL: Base URL of GraphDB server
            GRAPHDB_REPO: Repository name
            GRAPHDB_USER: Username (optional)
            GRAPHDB_PASSWORD: Password (optional)
    """
    backend = getattr(settings, 'TRIPLESTORE_BACKEND', 'fuseki')

    if backend == 'graphdb':
        # Future Enterprise profile implementation
        # from .graphdb_client import GraphDBClient
        # return GraphDBClient(
        #     url=settings.GRAPHDB_URL,
        #     repository=settings.GRAPHDB_REPO,
        #     username=getattr(settings, 'GRAPHDB_USER', None),
        #     password=getattr(settings, 'GRAPHDB_PASSWORD', None),
        # )
        raise NotImplementedError(
            "GraphDB backend is not yet implemented. "
            "Set TRIPLESTORE_BACKEND='fuseki' or wait for Enterprise profile."
        )
    elif backend == 'none':
        # Triplestore disabled
        return None
    else:
        # Default to Fuseki
        from .fuseki_client import FusekiClient
        return FusekiClient(
            fuseki_url=getattr(settings, 'FUSEKI_URL', None),
            dataset=getattr(settings, 'FUSEKI_DATASET', None),
            username=getattr(settings, 'FUSEKI_USER', None),
            password=getattr(settings, 'FUSEKI_PASSWORD', None),
        )
