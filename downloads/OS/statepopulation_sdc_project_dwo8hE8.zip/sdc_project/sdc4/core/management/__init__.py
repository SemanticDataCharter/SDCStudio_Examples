# Management module for core app
