"""
Django app configuration for arrest_report.
"""
from django.apps import AppConfig


class Arrest_reportConfig(AppConfig):
    """App configuration for arrest_report."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'arrest_report'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import arrest_report.signals  # noqa: F401
