"""
Django management command to initialize Fuseki RDF store.

Creates the default dataset and loads SDC4 ontologies.
"""
import os
import time
import requests
from pathlib import Path
from django.core.management.base import BaseCommand
from django.conf import settings


class Command(BaseCommand):
    help = 'Initialize Fuseki RDF store with SDC4 dataset and ontologies'

    def handle(self, *args, **options):
        fuseki_url = getattr(settings, 'FUSEKI_URL', 'http://fuseki:3030')
        base_url = fuseki_url.rsplit('/', 1)[0]  # Remove dataset name
        dataset_name = fuseki_url.rsplit('/', 1)[-1]  # Get dataset name

        # Fuseki credentials
        fuseki_password = os.environ.get('FUSEKI_PASSWORD', 'admin123')
        auth = ('admin', fuseki_password)

        # Wait for Fuseki to be ready (up to 60 seconds)
        self.stdout.write('Waiting for Fuseki to be ready...')
        for i in range(60):
            try:
                # Test with a simple query to the base URL
                response = requests.get(f"{base_url}/", timeout=5)
                if response.status_code == 200:
                    self.stdout.write(self.style.SUCCESS('✓ Fuseki is ready!'))
                    # Give it one more second to fully stabilize
                    time.sleep(1)
                    break
            except requests.exceptions.RequestException as e:
                if i % 10 == 0 and i > 0:  # Log every 10 seconds
                    self.stdout.write(f'  Still waiting... ({i}s elapsed)')
            time.sleep(1)
        else:
            self.stdout.write(
                self.style.WARNING(
                    'Fuseki did not respond in time. Continuing anyway - '
                    'you may need to run this command again after Fuseki is fully started.'
                )
            )
            return

        # Check if dataset exists by trying to query it
        # In Fuseki 5.x, dataset configuration is typically pre-configured via config files
        self.stdout.write(f'Checking if dataset "{dataset_name}" exists...')
        try:
            response = requests.get(
                f"{fuseki_url}/sparql",
                params={'query': 'SELECT * WHERE { ?s ?p ?o } LIMIT 1'},
                timeout=5
            )

            if response.status_code == 200:
                self.stdout.write(
                    self.style.SUCCESS(f'✓ Dataset "{dataset_name}" exists and is accessible!')
                )
            elif response.status_code == 404:
                self.stdout.write(
                    self.style.WARNING(
                        f'Dataset "{dataset_name}" not found.\n'
                        f'  In Fuseki 5.x, datasets should be pre-configured via /fuseki/configuration/*.ttl files.\n'
                        f'  The dataset configuration should be created during container initialization.'
                    )
                )
                return
            else:
                self.stdout.write(
                    self.style.WARNING(f'Unexpected response checking dataset: {response.status_code}')
                )
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error checking dataset: {e}'))
            return

        # Load SDC4 ontologies (Turtle format for triplestore)
        self.stdout.write(self.style.MIGRATE_HEADING('\nLoading SDC4 Ontologies'))
        # Ontologies are in the Django project root (same level as manage.py)
        ontologies_dir = Path(settings.BASE_DIR) / 'ontologies'
        ontology_files = [
            ('sdc4.ttl', 'SDC4 core ontology'),
            ('sdc4-meta.ttl', 'SDC4 metadata ontology'),
        ]

        for filename, description in ontology_files:
            ontology_path = ontologies_dir / filename

            if not ontology_path.exists():
                self.stdout.write(
                    self.style.WARNING(f'Ontology file not found: {ontology_path}')
                )
                continue

            self.stdout.write(f'Loading {description} ({filename})...')

            # Determine content type based on file extension
            content_type = 'text/turtle' if filename.endswith('.ttl') else 'application/rdf+xml'

            try:
                with open(ontology_path, 'rb') as f:
                    response = requests.post(
                        f"{fuseki_url}/data",
                        headers={'Content-Type': content_type},
                        auth=auth,
                        data=f.read(),
                        timeout=30
                    )

                if response.status_code in [200, 201, 204]:
                    self.stdout.write(self.style.SUCCESS(f'✓ Loaded {filename} successfully!'))
                else:
                    # Check if it's a duplicate error (already loaded)
                    if 'duplicate' in response.text.lower():
                        self.stdout.write(
                            self.style.WARNING(f'{filename} already loaded (skipping)')
                        )
                    else:
                        self.stdout.write(
                            self.style.ERROR(
                                f'Failed to load {filename}: {response.status_code} - {response.text}'
                            )
                        )

            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error loading {filename}: {e}'))

        # Load Data Model RDF schemas from project and apps
        self.stdout.write(self.style.MIGRATE_HEADING('\nLoading Data Model RDF Schemas'))

        from django.apps import apps
        dm_schemas_loaded = 0

        # Helper function to load RDF files from a directory
        def load_rdf_files(dmlib_dir, source_label):
            nonlocal dm_schemas_loaded
            if not dmlib_dir.exists():
                return

            # Find all dm-*.rdf or dm-*.ttl files
            dm_files = list(dmlib_dir.glob('dm-*.rdf')) + list(dmlib_dir.glob('dm-*.ttl'))

            for dm_file in dm_files:
                self.stdout.write(f'Loading DM schema: {dm_file.name} from {source_label}...')

                # Determine content type
                content_type = 'text/turtle' if dm_file.suffix == '.ttl' else 'application/rdf+xml'

                try:
                    with open(dm_file, 'rb') as f:
                        response = requests.post(
                            f"{fuseki_url}/data",
                            headers={'Content-Type': content_type},
                            auth=auth,
                            data=f.read(),
                            timeout=30
                        )

                    if response.status_code in [200, 201, 204]:
                        self.stdout.write(self.style.SUCCESS(f'✓ Loaded {dm_file.name} successfully!'))
                        dm_schemas_loaded += 1
                    else:
                        if 'duplicate' in response.text.lower():
                            self.stdout.write(
                                self.style.WARNING(f'{dm_file.name} already loaded (skipping)')
                            )
                        else:
                            self.stdout.write(
                                self.style.ERROR(
                                    f'Failed to load {dm_file.name}: {response.status_code} - {response.text}'
                                )
                            )

                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error loading {dm_file.name}: {e}'))

        # Load from project mediafiles/dmlib (same level as manage.py)
        project_dmlib = Path(settings.BASE_DIR) / 'mediafiles' / 'dmlib'
        load_rdf_files(project_dmlib, 'project root')

        if dm_schemas_loaded == 0:
            self.stdout.write(
                self.style.WARNING('No Data Model RDF schemas found.')
            )
            self.stdout.write(f'  DM schemas should be in: {project_dmlib}/dm-*.ttl')
        else:
            self.stdout.write(self.style.SUCCESS(f'\n✓ Loaded {dm_schemas_loaded} Data Model schema(s)'))

        self.stdout.write(self.style.SUCCESS('\n✓ Fuseki initialization complete!'))
        self.stdout.write(f'Dataset URL: {fuseki_url}')
