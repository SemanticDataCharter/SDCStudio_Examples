"""
Fuseki Client for RDF triple store operations.

This module provides a client for uploading RDF graphs to Apache Jena Fuseki
for semantic query and neuro-symbolic AI applications.
"""
import requests
from requests.auth import HTTPBasicAuth
from typing import Optional
import logging
from django.conf import settings

logger = logging.getLogger(__name__)


class FusekiClient:
    """
    Client for Apache Jena Fuseki triple store.

    Handles:
    - Graph upload with named graphs (with authentication)
    - SPARQL queries
    - Connection health checks
    """

    def __init__(
        self,
        fuseki_url: Optional[str] = None,
        dataset: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None
    ):
        """
        Initialize Fuseki client.

        Args:
            fuseki_url: Base URL of Fuseki server (default from settings)
            dataset: Dataset name (default from settings)
            username: Fuseki admin username (default from settings)
            password: Fuseki admin password (default from settings)
        """
        self.fuseki_url = fuseki_url or getattr(settings, 'FUSEKI_URL', 'http://localhost:3030/sdc4_rdf')
        self.dataset = dataset or getattr(settings, 'FUSEKI_DATASET', 'sdc4_rdf')

        # Authentication credentials
        self.username = username or getattr(settings, 'FUSEKI_USER', 'admin')
        self.password = password or getattr(settings, 'FUSEKI_PASSWORD', 'admin123')

        # Construct endpoints
        self.data_endpoint = f"{self.fuseki_url}/data"
        self.query_endpoint = f"{self.fuseki_url}/query"
        self.update_endpoint = f"{self.fuseki_url}/update"

        # Authentication object for requests
        self.auth = HTTPBasicAuth(self.username, self.password)

    def upload_graph(
        self,
        rdf_content: str,
        graph_uri: str,
        content_type: str = 'text/turtle'
    ) -> bool:
        """
        Upload RDF graph to Fuseki.

        Args:
            rdf_content: RDF content as string (Turtle format by default)
            graph_uri: Named graph URI
            content_type: MIME type of RDF content

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Use HTTP PUT to upload to named graph
            url = f"{self.data_endpoint}?graph={graph_uri}"

            headers = {
                'Content-Type': content_type
            }

            response = requests.put(
                url,
                data=rdf_content.encode('utf-8'),
                headers=headers,
                auth=self.auth,
                timeout=30
            )

            if response.status_code in [200, 201, 204]:
                logger.info(f"Successfully uploaded graph: {graph_uri}")
                return True
            else:
                logger.error(
                    f"Failed to upload graph {graph_uri}: "
                    f"Status {response.status_code}, Response: {response.text}"
                )
                return False

        except requests.RequestException as e:
            logger.error(f"Fuseki connection error: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error uploading graph: {e}")
            return False

    def delete_graph(self, graph_uri: str) -> bool:
        """
        Delete a named graph from Fuseki.

        Args:
            graph_uri: Named graph URI to delete

        Returns:
            bool: True if successful, False otherwise
        """
        try:
            url = f"{self.data_endpoint}?graph={graph_uri}"

            response = requests.delete(url, auth=self.auth, timeout=30)

            if response.status_code in [200, 204]:
                logger.info(f"Successfully deleted graph: {graph_uri}")
                return True
            else:
                logger.error(
                    f"Failed to delete graph {graph_uri}: "
                    f"Status {response.status_code}"
                )
                return False

        except requests.RequestException as e:
            logger.error(f"Fuseki connection error: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error deleting graph: {e}")
            return False

    def query_sparql(self, sparql_query: str) -> Optional[dict]:
        """
        Execute SPARQL query against Fuseki.

        Args:
            sparql_query: SPARQL query string

        Returns:
            dict: Query results in JSON format, or None if failed
        """
        try:
            headers = {
                'Content-Type': 'application/sparql-query',
                'Accept': 'application/json'
            }

            response = requests.post(
                self.query_endpoint,
                data=sparql_query.encode('utf-8'),
                headers=headers,
                auth=self.auth,
                timeout=60
            )

            if response.status_code == 200:
                return response.json()
            else:
                logger.error(
                    f"SPARQL query failed: "
                    f"Status {response.status_code}, Response: {response.text}"
                )
                return None

        except requests.RequestException as e:
            logger.error(f"Fuseki connection error: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error executing SPARQL query: {e}")
            return None

    def health_check(self) -> bool:
        """
        Check if Fuseki server is reachable.

        Returns:
            bool: True if server is healthy, False otherwise
        """
        try:
            # Try to access the dataset info endpoint
            url = f"{self.fuseki_url.rsplit('/', 1)[0]}/$/ping"

            response = requests.get(url, auth=self.auth, timeout=5)

            return response.status_code == 200

        except requests.RequestException:
            return False
        except Exception:
            return False

    def get_graph_uri(self, instance_id: str, dm_ct_id: str) -> str:
        """
        Generate graph URI for an instance.

        Creates a URL that references the graph location within the
        Fuseki triplestore dataset.

        Args:
            instance_id: Instance ID (e.g., i-abc123)
            dm_ct_id: Data Model CT ID

        Returns:
            str: Graph URI (e.g., http://localhost:3030/#/dataset/sdc4_rdf/dm-{ct_id}/{instance_id})
        """
        # Extract base URL (remove dataset path) for the graph URI
        base_url = self.fuseki_url.rsplit('/', 1)[0]
        return f"{base_url}/#/dataset/{self.dataset}/dm-{dm_ct_id}/{instance_id}"
