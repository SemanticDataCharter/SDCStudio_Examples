"""
SDC4 shared utilities package.

This package contains shared utilities used across all SDC4 apps in this project.
When combining multiple apps into one Django project, these utilities are shared
rather than duplicated in each app.
"""
