"""
Django app configuration for incident_report.
"""
from django.apps import AppConfig


class Incident_reportConfig(AppConfig):
    """App configuration for incident_report."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'incident_report'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import incident_report.signals  # noqa: F401
