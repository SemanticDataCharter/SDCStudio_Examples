"""
API app for SDC4 REST API.
"""
default_app_config = 'api.apps.ApiConfig'
