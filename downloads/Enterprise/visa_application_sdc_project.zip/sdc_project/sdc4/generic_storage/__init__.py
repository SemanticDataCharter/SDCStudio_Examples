"""
Generic storage app for SDC4 XML instances without dedicated apps.
"""
default_app_config = 'generic_storage.apps.GenericStorageConfig'
