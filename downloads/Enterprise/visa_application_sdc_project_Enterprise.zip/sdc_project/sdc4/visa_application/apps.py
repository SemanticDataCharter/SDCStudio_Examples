"""
Django app configuration for visa_application.
"""
from django.apps import AppConfig


class Visa_applicationConfig(AppConfig):
    """App configuration for visa_application."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'visa_application'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import visa_application.signals  # noqa: F401
