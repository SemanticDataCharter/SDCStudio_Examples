"""
Core app for sdc4.

This app contains management commands and utilities for project initialization.
"""
