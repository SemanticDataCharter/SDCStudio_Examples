# Using Your SDC4 Data Model with AI Assistants

This package contains a complete SDC4-compliant data model that you can use with AI assistants (Claude, ChatGPT, Gemini, etc.) to generate custom applications, APIs, or data tools.

## 📦 Package Contents

Your ZIP package includes:

- **`dm-njvi3y45lasere3hr5506i54.xsd`** - XML Schema Definition (your data model structure)
- **`dm-njvi3y45lasere3hr5506i54.xml`** - XML instance example with sample data
- **`dm-njvi3y45lasere3hr5506i54-instance.json`** - JSON instance example (same structure as XML)
- **`dm-njvi3y45lasere3hr5506i54.jsonld`** - JSON-LD semantic schema description
- **`dm-njvi3y45lasere3hr5506i54.html`** - Human-readable model documentation
- **`dm-njvi3y45lasere3hr5506i54_shacl.ttl`** - SHACL shapes for RDF validation
- **`dm-njvi3y45lasere3hr5506i54.ttl`** - RDF triples extracted from XSD (Turtle format)
- **`dm-njvi3y45lasere3hr5506i54.rdf`** - RDF triples extracted from XSD (RDF/XML format)
- **`README-SHACL.md`** - SHACL usage guide
- **`README-AI-PROMPT.md`** - This file

## 🤖 Quick Start with AI Assistants

### Basic Prompt Template

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model and need help creating a data entry application.

**Attached Files:**
- XML Schema (dm-njvi3y45lasere3hr5506i54.xsd)
- Example instance (dm-njvi3y45lasere3hr5506i54.xml)
- HTML documentation (dm-njvi3y45lasere3hr5506i54.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here, for example:]
- User authentication
- Multi-user support
- Specific UI requirements
- Integration with other systems
- Deployment target (local/cloud)

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on this SDC4 schema.
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend.
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from this SDC4 schema with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for this data model.
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## ✅ SDC4 Validation (Optional but Recommended)

For **full SDC4 compliance** with XML validation, your application should use the `sdcvalidator` Python library.

### Why Use sdcvalidator?

- ✅ **Complete SDC4 Validation**: Validates XML against SDC4 reference model
- ✅ **ExceptionValue Support**: Allows justified constraint violations with documentation
- ✅ **Enhanced Error Messages**: Detailed validation feedback
- ✅ **SDC4-Specific Rules**: Beyond standard XML Schema validation

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import validate_xml

# Validate XML instance against schema
result = validate_xml(
    xml_file='data.xml',
    xsd_file='dm-njvi3y45lasere3hr5506i54.xsd'
)

if result.is_valid:
    print("✅ Valid SDC4 XML instance")
else:
    print("❌ Validation errors:")
    for error in result.errors:
        print(f"  - {error}")
```

### ExceptionValue Injection

When a data value violates constraints but is justified:

```python
from sdcvalidator import inject_exception_value

# Example: Age is 150 (violates max constraint) but documented
inject_exception_value(
    xml_element=age_element,
    exception_reason="Patient is Guinness World Record holder",
    exception_source="Medical records verification"
)
```

### Important Note

**XML validation is completely optional.** You can build applications that:
- Use only JSON (ignore XML entirely)
- Implement custom validation
- Use the schema structure without SDC4 validation
- Add sdcvalidator later if needed

Choose based on your requirements:
- **Need SDC4 compliance?** → Use sdcvalidator
- **Just need the data structure?** → Use schema without validation
- **Building internal tools?** → Custom validation is fine

## 💡 Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

Don't try to build everything at once:
- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Provide Context

Help the AI understand your use case:
- Who will use this application?
- What's the primary workflow?
- Are there any critical constraints?
- What's the deployment environment?

### 4. Leverage the Documentation

The `dm-njvi3y45lasere3hr5506i54.html` file contains:
- Human-readable descriptions
- Constraint definitions
- Business rules
- Semantic links

Share this with the AI for better understanding.

### 5. Ask for Explanations

Request the AI to explain:
- Why it chose a particular approach
- How to customize or extend the code
- Best practices for your framework
- Testing strategies

## 🛠️ Common Patterns

### Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster → Database Table
Sub-Cluster → Separate Table with Foreign Key
Component → Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster → Table
Sub-Clusters → JSON Column
Components → Mixed (simple types as columns, complex as JSON)
```

**Option 3: Hybrid (Flexible)**
```
Frequently queried clusters → Normalized tables
Deeply nested structures → JSON embedding
Balance between query performance and simplicity
```

Ask your AI assistant which approach fits your use case.

### XML Instance Storage

Consider storing the complete XML instance:

```sql
CREATE TABLE data_model (
    id INTEGER PRIMARY KEY,
    -- Regular columns for each component
    customer_name TEXT,
    customer_email TEXT,
    -- XML instance for full SDC4 compliance
    xml_instance TEXT,
    -- Metadata
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

Benefits:
- Full SDC4 validation at any time
- Preserve complete semantic information
- Enable XML export
- Audit trail of exact data structure

## 📚 Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)
- GitHub Repository (check PyPI for link)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

## 🎯 Next Steps

1. **Review Documentation**: Open `dm-njvi3y45lasere3hr5506i54.html` to understand your data model
2. **Choose Framework**: Decide which technology fits your needs
3. **Customize Prompt**: Fill in the template above with your requirements
4. **Start Conversation**: Paste into Claude, ChatGPT, or your preferred AI assistant
5. **Iterate**: Work with the AI to refine and improve the generated code

## ❓ Questions?

If you have questions about:
- **The data model**: Review the HTML documentation
- **SDC4 specification**: Visit semanticdatacharter.org
- **SDCStudio**: Contact support@axius-sdc.com
- **sdcvalidator**: Check PyPI documentation

---

**Generated by SDCStudio** - Your SDC4-compliant data modeling platform

This package and all included files are ready to use with any AI assistant to generate custom applications tailored to your needs.
